﻿namespace LargestNumberFinder
{
    public class NumberProgram
    {
        string[] numberList = new string["24", "25", "60", "73", "20", "14", "45", "75", "90", "89"];

        int a = 0;
        int b = 0;
        int c = 0;

        static void Main(string[] args)
        {
            while (a <= 10)
            {
                ProcessInput(numberList[a], c);
                a++;
            }
            Console.WriteLine(c);
        }

        public static int ProcessInput(string input, ref int largest)
        {
            b = Int32.Parse(input);
            if(b > largest)
            {
                largest = b;
                c = b;
            }
            return c;
        } 
    }
}
